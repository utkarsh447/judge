const fs = require('fs');
const path = require('path');
const exec = require('sync-exec');
const asyncExec = require('child_process').exec;
const {commands,statusCodes} = require('./commands.js');

/*
         * @function
         * @name directorySetup
         * @description Function that creates a folder which will be mounted to a docker container in which  we will
           execute the user submitted code.First the code is written to a file and then the input and ouput files for the problem 
         * is copied into the folder.
         * 
         * @param {compiler} compiler for the selected language.
         * @param {code} Code submitted by user.
         * @param {Problem} Problem for which code was submitted
         * return {dirPath} Directory path that was created and will be mounted to the container.
*/
function directorySetup(compiler){
	//Unique identifier for the folder to avoid collisions and allow parallel execution 
	var uid = Math.random().toString(36).substr(2, 5);
	var file =`main.${commands[compiler]['extension']}`;
	var code = (fs.readFileSync(file, 'utf8'));
	var dirPath = path.join(__dirname,uid) ;
	fs.mkdirSync(dirPath);
	fs.writeFileSync(path.join(dirPath,file),code);
	fs.copyFileSync('in.txt',path.join(dirPath,'in.txt'));
	return dirPath ;
}
/*
         * @function
         * @name final Command
         * @description Function that will return the final command that will be executed for the evaluation of the code.
         * 
         * @param {compiler} compiler for the selected language.
         * @param {containerCommand} container command appended with the docker container.
         * @param {tl} allowed time limit for execution
         * return {command} final command for execution
*/

function finalCommand(compiler,containerCommand,tl){
 	var commandCompile = commands[compiler]['compilation'] ;
 	var commandExec = commands[compiler]['run'] ;
	var command = "" ;
	if(commandCompile !="")
		command = `${containerCommand} ${commandCompile} && ` ;
	command += `${containerCommand} timeout ${tl} ${commandExec} < in.txt` ;
	return command ;
}

/*
         * @function
         * @name checker
         * @description Function that will judge the user submitted code.
*/
function checker(){
	//these outputs will be provided by the user via a form.
	var compiler = 'cpp';
 	var tl = '1' ;
 	var judge = {};

 	judge['verdict'] = 'Not evaluated';
	dirPath = directorySetup(compiler) ;
	//create the container with a folder mounted to it having all dependencies and input files required for execution
	try{
	container = (exec(`docker run -it -d  -v ${dirPath}:/usr/src/app sandbox`));
	//command which is required for executing statements in a docker sandbox.Docker containers can be uniquely identified with
	//their first three characters of the container ID.
	var containerCommand = `docker exec -i ${container.stdout.substring(0,3)}`;
	}catch(err){
		throw err;
	}
	res = exec(finalCommand(compiler,containerCommand,tl)) ;
	//code executed in the given time limit without throwing any exception.Now check if the ouput matches with the required output.
	judge['status'] = statusCodes[res.status] ;
	if(res.status === 0){
		res.stdout.trim() ;
		expected = fs.readFileSync('out.txt','utf8') ;
		expected.trim() ;
		judge['verdict'] = (res.stdout === expected ?'AC':'WA');
	}
	//compiler error
	if(res.status ===1){
		judge['error_message'] = res.stderr ;
	}
	//We can kill the container asynchronously as the evaluation process is completed and judgement can be returned without blocking.
	asyncExec(`docker rm -f ${container.stdout.substring(0,3)}`, (err, stdout, stderr) => {callback(err,stdout,stderr)});
	return judge ;
}

function callback(err,stdout,stderr){
	if (err){
		throw err ;
	}
	return ;
}
console.log(checker());

