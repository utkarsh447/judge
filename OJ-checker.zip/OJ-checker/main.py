T = int(raw_input())
print 'lol'
for i in range(0,T):
    x = int(raw_input())
    print x
