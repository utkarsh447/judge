const fs = require('fs');
const {commands}= require('./commands.js');
const path = require('path');
const exec = require('child-process-promise').exec;
const {to} = require('await-to-js');
const catchify = require('catchify');
async function func(){
	var file = 'main.cpp';
	var compiler = 'cpp';
 	var tl='1' ;
 	var commandCompile = commands[compiler]['compilation'] ;
 	var commandExec = commands[compiler]['run'] ;
	code=(fs.readFileSync(file, 'utf8'));
	var uid = Math.random().toString(36).substr(2, 5);
	var dirPath = path.join(__dirname,uid) ;
	fs.mkdirSync(dirPath);
	fs.writeFileSync(path.join(dirPath,file),code);
	try{
	[err,res] = await catchify(exec(`docker run -d -it -v ${dirPath}:/usr/src/app sandbox`));
	}catch(err){
		throw err;
	}
	var containerCommand=`docker exec ${res.stdout.substring(0,3)}`;
	console.log(`${containerCommand} ${commandCompile} && ${containerCommand} ${commandExec} timeout ${tl} ${commandExec}`);
	if (commandCompile !=="")
		[err,res] = await catchify(exec(`${containerCommand} ${commandCompile} && ${containerCommand} timeout ${tl} ${commandExec}`));
	else
		[err,res] = await catchify(exec(`${containerCommand} ${commandExec} timeout ${tl} ${commandExec}`));
	if(err){
		console.log(err);
		console.log(err.stderr);
	}
	else
		console.log(res.stdout);
	return res ;
}

func()

process.on('unhandledRejection', error => {
  // Won't execute
  console.log('unhandledRejection', error);
});

