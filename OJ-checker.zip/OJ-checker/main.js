console.log('lol from node js');

/*
FROM ubuntu
FROM python:2
FROM python:3
FROM node:carbon
FROM gcc
RUN mkdir -p /usr/src/app
COPY . /usr/src/app
WORKDIR /usr/src/app
RUN npm install
COPY . /usr/src/app
WORKDIR /usr/src/app
*/
