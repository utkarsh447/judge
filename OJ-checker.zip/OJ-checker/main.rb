puts 'Hello world from ruby'
