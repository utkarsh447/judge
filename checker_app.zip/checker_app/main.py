T = int(raw_input())
for i in range(0,T):
    x = int(raw_input())
    print x
