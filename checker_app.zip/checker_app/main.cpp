#include <iostream>
#include<vector>
#include<algorithm>
using namespace std;

int main() {
  int T,x;
  cin>>T ;
  while(T--){
	cin>>x ;
	cout<<x<<endl ;
}   
  return 0;
}

