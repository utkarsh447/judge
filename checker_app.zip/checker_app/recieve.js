#!/usr/bin/env node
var amqp = require('amqplib/callback_api');
var fs = require('fs');
var path = require('path');
var axios = require('axios');
const exec = require('sync-exec');
const asyncExec = require('child_process').exec;
const {checker,directorySetup} = require('./docker.js');

amqp.connect('amqp://localhost', function(err, conn) {
  conn.createChannel(function(err, ch) {
    var q = 'hello';
    ch.assertQueue(q, {durable: false});
    ch.prefetch(1);
    ch.consume(q, function(msg) {
	    var message = (JSON.parse(msg.content.toString()));
	    try{
	    //The directory to be mounted to the container which will contain the test case folder and the file with code.
	    dirPath = directorySetup(message['compiler'],message['id']) ;
	    //Execute the command to create the container with directory mounted to it.
		container = (exec(`docker run -it -d  -v ${dirPath}:/usr/src/app sandbox`));
		}catch(err){
			throw err;
		}
		var source = path.join(__dirname,`testcases/input/${message['id']}`)
		console.log(source);
		fs.readdirSync(source,'utf8').forEach(function(val){
			console.log(checker(container,message['compiler'],message['tl'],val,message['id']));
		});	
		axios.post('http://localhost:8000/notify',{'clientid':message['clientid'],'result':'task complete'}).catch(function(err){ console.log(err)});
		//Remove the container and the directory mounted to the container asynchronously
		asyncExec(`docker rm -f ${container.stdout.substring(0,3)} ; rm -rf ${dirPath}`, (err, stdout, stderr) => {callback(err,stdout,stderr)});
	    }, {noAck: true});
  });
});